'use strict';

const aws = require("aws-sdk");
aws.config.update( { region: "eu-central-1" } );
const s3 = new aws.S3();
var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;

const _archiver = require('archiver');
var allKeys=[];
var size = 0;
var sizeCount = false;
var lockExists = false;
exports.handler = async (_req, _ctx, _cb) => {
    console.log('start');
    
    var eventId = _req["Records"][0]["s3"]["object"]["key"].split('/')[0];
    var bucketName = _req["Records"][0]["s3"]["bucket"]["name"];
    var key = _req["Records"][0]["s3"]["object"]["key"];
    var lockFileKey = eventId+'/zip/'+size+'.lock';
    
    await countObjects(bucketName, eventId+"/");
    while(!sizeCount){
      await sleep(300);
    }
    console.log("size: "+size);
    var zipfileKey = eventId+'/zip/'+size+'.zip';
    console.log(zipfileKey);
    
    var paramsZipExist = {Bucket: bucketName, Key: zipfileKey};
    
    try { 
      await s3.headObject(paramsZipExist).promise();
      CallAPI(eventId);
      console.log("zip exists");
      Clean();
      return;
    } catch (headErr) {
      console.log(headErr);
    }
    
    var paramsLockExist = {Bucket: bucketName, Key: lockFileKey};
    
    try { 
      await s3.headObject(paramsLockExist).promise();
      lockExists = true;
    } catch (headErr) {
    }
    
    if(lockExists){
      console.log("lock exists");
      Clean();
      return;
    }
    await s3.putObject({
      Key: lockFileKey,
      Bucket: bucketName,
      Body: 'LOCK'
    }).promise()
    
    var getParams = {
      Bucket: bucketName,
      Key: key
    }
    
    const dataSubData = await s3.getObject({  
      Bucket: bucketName,
      Key: key
    }).promise();
    
    var subscriptions = JSON.parse(dataSubData.Body.toString('utf-8'));
    console.log(subscriptions);
    
    await prepareKeys(subscriptions,eventId+'/')
    console.log(allKeys);
    await zipIt(bucketName,zipfileKey);
    CallAPI(eventId);
    await s3.deleteObject(paramsLockExist).promise();
    Clean();
    _cb(null, { } );
};

function Clean(){
  allKeys=[];
  size = 0;
  sizeCount = false;
  lockExists = false;
}

function CallAPI(eventId){
  console.assert("call");
  var xhr = new XMLHttpRequest();
  xhr.open("POST", "https://devlogin.kamero.in/v1/zip_ready", true);
  xhr.setRequestHeader('Content-Type', 'application/json');
  xhr.send(JSON.stringify({
    eventDocId: eventId
  }));
}

async function prepareKeys(subscriptions,prefix){
  for (var key in subscriptions) {
    for(var i=0;i<subscriptions[key].length;i++){
      allKeys.push({
        from:prefix+subscriptions[key][i],
        to:key+'/'+subscriptions[key][i]
      });
    }
  }
}

//This returns us a stream.. consider it as a real pipe sending fluid to S3 bucket.. Don't forget it
const streamTo = (_bucket, _key) => {
	var stream = require('stream');
	var _pass = new stream.PassThrough();
	s3.upload( { Bucket: _bucket, Key: _key, Body: _pass }, (_err, _data) => { /*...Handle Errors Here*/ } );
	return _pass;
};


async function zipIt(bucketName,zipfileKey){
	
	
    var _list = await Promise.all(allKeys.map(_key => new Promise((_resolve, _reject) => {
            let params = {Bucket: bucketName, Key: _key["from"]}
            //s3.getObject(params).then(_data => _resolve( { data: _data.Body, name: `${_key.split('/').pop()}` } ));
            var data = s3.getObject(params);
            _resolve( { data: data, name: _key["to"] } );
        }
    ))).catch(_err => { throw new Error(_err) } );

    await new Promise((_resolve, _reject) => { 
        var _myStream = streamTo(bucketName, zipfileKey);		//Now we instantiate that pipe...
        var _archive = _archiver('zip');
        _archive.on('error', err => { throw new Error(err); } );
        
        //Your promise gets resolved when the fluid stops running... so that's when you get to close and resolve
        _myStream.on('close', _resolve);
        _myStream.on('end', _resolve);
        _myStream.on('error', _reject);
        
        _archive.pipe(_myStream);			//Pass that pipe to _archive so it can push the fluid straigh down to S3 bucket
        _list.forEach(_itm => _archive.append(_itm.data.createReadStream(), { name: _itm.name } ) );		//And then we start adding files to it
        _archive.finalize();				//Tell is, that's all we want to add. Then when it finishes, the promise will resolve in one of those events up there
    }).catch(_err => { throw new Error(_err) } );
}

async function listAllKeys(bucketName, prefix, token)
{
  
  var listParams = { 
   Bucket: bucketName,
   Delimiter: '/',
   Prefix:prefix
  }
    
  if(token) listParams.ContinuationToken = token;

  s3.listObjectsV2(listParams, function(err, data){
      console.log(data.Contents);
      for(var i=0;i<data.Contents.length;i++){
          allKeys.push(data.Contents[i].Key);
      }

    if(data.IsTruncated)
      listAllKeys(data.NextContinuationToken);
    else
      zipIt();
  });
}

function countObjects(bucketName, prefix, token){
  
  var countParams = { 
     Bucket: bucketName,
     Delimiter: '/',
     Prefix: prefix,
     ContinuationToken : token
    };
  
  s3.listObjectsV2(countParams, function(err, data){
    size = size + data.Contents.filter(item => item.Key.endsWith('.jpg')).length;
      
    if(data.IsTruncated)
      countObjects(bucketName, prefix, data.NextContinuationToken);
    else
      sizeCount=true;
  });
}

function sleep(ms) {
  return new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
}   
